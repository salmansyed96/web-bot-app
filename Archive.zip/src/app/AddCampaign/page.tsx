export default function LemonPage(){
    return( <>
     <h1 style={{ marginLeft: '40px', marginRight: '40px', marginTop: '40px', fontWeight: 'bold', fontSize: '40px' }}>
    Add Campaign
  </h1>





    </>
        
       
    )
}





