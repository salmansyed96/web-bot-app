import React from 'react'

const page = () => {
  return (
    
    <h1 style={{ marginLeft: '40px', marginRight: '40px', marginTop: '40px', fontWeight: 'bold', fontSize: '40px' }}>
    Compaign Details 
  </h1>
  )
}

export default page
