import LoginForm from "@/app/LoginPage/page";

const HomePage: React.FC = () => {
  return (
    <div>
      <LoginForm />
    </div>
  );
};

export default HomePage;
